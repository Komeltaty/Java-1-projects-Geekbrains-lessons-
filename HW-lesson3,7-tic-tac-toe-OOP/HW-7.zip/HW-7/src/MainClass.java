import game.Game;

public class MainClass {
    public static void main(String[] args) {
     Game gameInstance = new Game();
gameInstance.initGame(0);

    }
}
//улучшить: сделать чтоб при окончании игра игра снова запускалась с человека
//иногд после ничей не обновляется поле
//при обновлении игры играешь то 0 то Х


//добавила проверку на ничью после хода компьютера
//сделала чтобы новая игра игралась снова крестиками